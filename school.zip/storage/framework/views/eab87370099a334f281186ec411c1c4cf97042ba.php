<?php $__env->startSection('content'); ?>
<br><br>
    <div class="container-fluid panel panel-default">
    <h1>Editando: <?php echo $tema->title; ?></h1>
    <hr>

    <?php echo Form::model($tema, ['method'=>'PATCH', 'action' => ['TemasController@update', $tema->id]]); ?>

        <?php echo $__env->make('temas.form',['submitButtonText'=>'Actualizar Tema'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>