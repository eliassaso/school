<?php $__env->startSection('content'); ?>
<br><br>
    <div class="container-fluid panel panel-default">
        <h1>Sus materias</h1>
        <table class="table table-striped">
            <tr>
                <td><strong>Grado</strong></td>
                <td><strong>Nombre</strong></td>
                <td><strong>Ver temas</strong></td>
            </tr>

            <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                <article>
                    <tr>
                        <td><h4><?php echo e($materia->degree); ?></h4></td>
                        <td><h4><?php echo e($materia->nombre_materia); ?></h4></td>
                        <td class="">
                            <?php echo Form::open(['url' => 'temas/'.$materia->id,
                                 'method' => 'GET',
                                 'class' => 'formDelete',
                                  'id' => 'form'.$materia->id]); ?>

                            <div class="ui buttons">
                                <?php echo Form::hidden('id_materia', $materia->id, ['class'=>'form-control']); ?>

                                <button type="submit" class="waves-effect waves-light btn-large btn tooltipped" data-position="right" data-delay="50" data-tooltip="Ver tema"><i class="material-icons">send</i></button>
                            </div>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                    

                    <div class="body">

                    </div>
                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </table>
        <br>
        <a class="waves-effect waves-light btn-large" href="/home"
           role="button">Volver</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('/js/main.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>