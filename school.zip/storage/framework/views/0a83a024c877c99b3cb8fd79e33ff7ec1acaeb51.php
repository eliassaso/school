<html>
<head></head>
<body style="background: ; color: ;">
<h1><?php echo e($email); ?></h1>
<p><?php echo $content; ?></p>
</body>
</html>