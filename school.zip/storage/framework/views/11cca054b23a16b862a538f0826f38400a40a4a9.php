<?php $__env->startSection('content'); ?>
<br><br><br><br>
guia

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>