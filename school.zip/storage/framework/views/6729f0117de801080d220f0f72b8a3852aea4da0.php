<?php $__env->startSection('content'); ?>
    <div class="container-fluid panel panel-default">
        <h1>Materias</h1>
        <table class="table table-striped">
            <tr>
                <td><strong>Materias</strong></td>
                <td><strong>Borrar</strong></td>
            </tr>

                <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <article>
                        <tr>
                            <td><a href="/materias/<?php echo e($materia->id); ?>/edit"><h4><?php echo e($materia->degree); ?> - <?php echo e($materia->nombre_materia); ?> </h4></a></td>
                            <td>
                                <?php echo Form::open(['url' => 'materias/'.$materia->id,
                                     'method' => 'DELETE',
                                     'class' => 'formDelete',
                                      'id' => 'form'.$materia->id]); ?>

                                <div class="ui buttons">
                                    <a class="btn btn-danger glyphicon glyphicon-trash" id="<?php echo e($materia->id); ?>" data-title="assignDelete" data-toggle="modal" data-target="#delete" data-placement="top"><i class="icon Delete"></i>Delete</a>
                                </div>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        

                        <div class="body">

                        </div>
                    </article>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </table>
        <?php echo $materias->render(); ?>

        <br>
        <a class="waves-effect waves-light btn" href="<?php echo e(url('materias/create')); ?>"
           role="button">Crear materia</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('/js/main.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('materias.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>