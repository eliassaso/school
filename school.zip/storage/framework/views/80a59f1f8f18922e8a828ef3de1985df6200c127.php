<?php $__env->startSection('content'); ?>
<br><br>
    <div class="container-fluid panel panel-default">
        <h1>Temas</h1>
        <h3>Materia: <?php echo e($materia->nombre_materia); ?>, grado: <?php echo e($materia->degree); ?> </h3>
        <table class="table table-striped">
            <tr>
                <td><strong>Temas</strong></td>
                <td><strong>Funciones</strong></td>
            </tr>

                <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <article>
                        <tr>
                            <td><a href="/temas/<?php echo e($tema->id); ?>/edit"><h4><?php echo e($tema->title); ?> </h4></a></td>
                            <td>
                                <div class="ui buttons">
                                    <a class="btn-floating btn-large waves-effect waves-light red" id="<?php echo e($tema->id); ?>" data-title="assignDelete" data-toggle="modal" data-target="#delete" data-placement="top"><i class="material-icons">delete</i></a>
                                    <a class="btn-floating btn-large waves-effect waves-light green" href="/temas/<?php echo e($tema->id); ?>/edit" id="<?php echo e($tema->id); ?>" ><i class="material-icons">edit</i></a>
                                    <a class="btn-floating btn-large waves-effect waves-light blue" href="/preguntas/<?php echo e($tema->id); ?>" id="<?php echo e($tema->id); ?>" ><h4 style="margin-top: 10px;">?</h4><i class="material-icons">questio</i></a>
                                </div>
                            </td>
                        </tr>
                        

                        <div class="body">

                        </div>
                    </article>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </table>

        <br>
        <a class="waves-effect waves-light btn" href="/createma/<?php echo e($materia->id); ?>"
           role="button">Crear Tema</a>
        <a class="waves-effect waves-light btn" href="/dashboard"
           role="button">Volver</a>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('/js/main.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('materias.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>