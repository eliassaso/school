<?php $__env->startSection('content'); ?>
<br><br>
    <h1>Reclutar profesor</h1>
    <hr>

    <?php echo Form::open(['url' => 'profesores/reclutar']); ?>

        <?php echo $__env->make('profesores.form',['submitButtonText'=>'Agregar profesor'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>