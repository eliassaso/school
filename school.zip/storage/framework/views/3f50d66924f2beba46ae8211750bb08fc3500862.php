<?php $__env->startSection('content'); ?>
<br><br>
    <div class="container-fluid panel panel-default">
        <h1>Profesores</h1>
        <table class="table table-striped">
            <tr>
                <td><strong>Profesores</strong></td>
                <td><strong>Cédula</strong></td>
                <td><strong>Funciones</strong></td>
            </tr>

                <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <article>
                        <tr>
                            <td><a href="/profesores/<?php echo e($profesor->id); ?>/edit"><h4><?php echo e($profesor->name); ?>  <?php echo e($profesor->last_name); ?> </h4></a></td>
                            <td><h4><?php echo e($profesor->charter); ?></h4></td>
                            <td class="navbar-right">
                                <div class="ui buttons">
                                    <a href="/profesores/<?php echo e($profesor->id); ?>/impartidas" class="btn-floating btn-large waves-effect waves-light blue btn tooltipped" data-position="left" data-delay="50" data-tooltip="Impartidas" id="<?php echo e($profesor->id); ?>"><i class="material-icons">play_for_work</i></a>
                                    <a href="/profesores/<?php echo e($profesor->id); ?>/edit" class="btn-floating btn-large waves-effect waves-light green btn tooltipped" data-position="right" data-delay="50" data-tooltip="Asignar" id="<?php echo e($profesor->id); ?>"><i class="material-icons">input</i></a>
                                </div>
                            </td>
                        </tr>
                        

                        <div class="body">

                        </div>
                    </article>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </table>
        <?php echo $profesores->render(); ?>

        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('/js/main.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profesores.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>