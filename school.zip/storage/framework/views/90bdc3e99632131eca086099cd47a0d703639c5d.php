<?php $__env->startSection('content'); ?>

<div style='margin-top: 10px;' class="container-fluid" id = 'main'>
<div class="col s12">

        <div class="col s12" id="">
        <?php echo Form::open(['method'=>'POST', 'action' => ['FrontController@includeNewToken']]); ?>

            <div class="form-group">
                <?php echo Form::hidden('idTema', $id, ['class'=>'form-control']); ?>

            </div>
            <br><br>
            <div class="form-group input-field col s12">
                <?php echo Form::label('degree','Grado: '); ?> <br><br>
                <?php echo Form::select('degree', array('1' => '1', '2' => '2','3' => '3','4' => '4','5' => '5','6' => '6',
                '7' => '7','8' => '8','9' => '9','10' => '10','11' => '11',), null, array('class'=>'form-control browser-default')); ?>

            </div>
            <div class="col s6">
                <?php echo Form::label('licencia','Digite su licencia'); ?>

                <?php echo Form::text('licencia', null , ['class'=>'col s6']); ?>

            </div>

            <!-- Submit -->
            <button class = 'waves-effect waves-light btn left hoverable' type = "submit">
                <?php echo Form::submit('Enviar', ['class' => '']); ?>

            </button>


        <?php echo Form::close(); ?>


        <br><br>
        <span class = "red-text darken-1"><?php echo $mensaje; ?></span>

        </div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>