<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 5px;">
<div class="row">
<div class="col s12">

  <nav>
    <div class="row">
      <div class="col s12">
        <a style="margin-left: 10px;" href="/home" class="breadcrumb">Principal</a>
        <a href="<?php echo e(url('/front/'.$materia->degree)); ?>" class="breadcrumb">Grado <?php echo $materia->degree; ?></a>
        <a href="<?php echo e(url('/titulos/'.$materia->id)); ?>" class="breadcrumb"><?php echo $materia->nombre_materia; ?></a>
      </div>
    </div>
  </nav>

    <ul style="font-family: Roboto, sans-serif;
                  font-size: 2.2em;
                  /*font-style: italic;*/
                  font-weight: 200;
                  line-height: 1.5em;
                  letter-spacing: 0em;
                  color: #26a69a;
                  background-color: #fff;
                  /*display: inline-block;*/
    " class="collection with-header z-depth-2">

    <?php if(count($temas)>0): ?> <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <li class="collection-item" style="



    "><div class=""><?php echo $tema->title; ?> <a style="color:#867777;" class="secondary-content" href="<?php echo e(url('/finalshow/'.$tema->id)); ?>" title=""><i class="material-icons">send</i></a></div></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php endif; ?>
    </ul>
</div>
</div>
</div>
   
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>