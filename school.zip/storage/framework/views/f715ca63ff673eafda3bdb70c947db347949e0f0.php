 <!-- Title Form Input -->
 <br><br>
<div class="container-fluid">


    <!-- Body Form Input -->
    <div class="form-group">
        <?php echo Form::label('charter','Numero de cedula: '); ?>

        <?php echo Form::text('charter', null , ['class'=>'form-control']); ?>

    </div>

    <!-- Submit -->

        <?php echo Form::submit($submitButtonText, ['class'=>'btn']); ?>


</div>

<?php if($error!=null): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <li><?php echo e($error); ?></li>
        </ul>
    </div>
<?php endif; ?>
