<html>
<head></head>
<body style="background: ; color: ;">
<h1>{{ $email }}</h1>
<p>{!! $content !!}</p>
</body>
</html>