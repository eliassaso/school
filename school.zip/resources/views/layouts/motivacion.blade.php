@extends('app')

@section('content')
<br><br><br><br>
Motivacion

@stop
